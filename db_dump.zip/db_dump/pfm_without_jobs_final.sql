/*
 Navicat Premium Data Transfer

 Source Server         : platform_it
 Source Server Type    : MariaDB
 Source Server Version : 100427
 Source Host           : localhost:3306
 Source Schema         : pfm

 Target Server Type    : MariaDB
 Target Server Version : 100427
 File Encoding         : 65001

 Date: 03/07/2023 20:00:45
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for adresses
-- ----------------------------
DROP TABLE IF EXISTS `adresses`;
CREATE TABLE `adresses`  (
  `adress_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `adress_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `adress_user_id` int(10) UNSIGNED NULL DEFAULT NULL,
  PRIMARY KEY (`adress_id`) USING BTREE,
  INDEX `adress_user_id`(`adress_user_id`) USING BTREE,
  CONSTRAINT `adress_user_id` FOREIGN KEY (`adress_user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of adresses
-- ----------------------------
INSERT INTO `adresses` VALUES (1, 'Невский пр., д. 5, кв 7', 1);
INSERT INTO `adresses` VALUES (2, 'Невский пр., д. 5, кв 8', 1);
INSERT INTO `adresses` VALUES (3, 'Невский пр., д. 5, кв 10', 2);
INSERT INTO `adresses` VALUES (4, 'Невский пр., д. 5, кв 11', 2);
INSERT INTO `adresses` VALUES (7, 'Невский пр., д. 5, кв 120', 3);

-- ----------------------------
-- Table structure for carts
-- ----------------------------
DROP TABLE IF EXISTS `carts`;
CREATE TABLE `carts`  (
  `cart_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `cart_product_id` int(10) UNSIGNED NOT NULL,
  `cart_product_count` tinyint(3) UNSIGNED NOT NULL,
  `cart_order_id` int(10) UNSIGNED NOT NULL,
  `cart_product_price` int(10) UNSIGNED NULL DEFAULT NULL,
  PRIMARY KEY (`cart_id`) USING BTREE,
  INDEX `cart_order_id`(`cart_order_id`) USING BTREE,
  INDEX `cart_product_id`(`cart_product_id`) USING BTREE,
  CONSTRAINT `cart_order_id` FOREIGN KEY (`cart_order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cart_product_id` FOREIGN KEY (`cart_product_id`) REFERENCES `products` (`product_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of carts
-- ----------------------------
INSERT INTO `carts` VALUES (1, 1, 2, 1, NULL);
INSERT INTO `carts` VALUES (2, 4, 3, 2, NULL);
INSERT INTO `carts` VALUES (3, 6, 3, 3, NULL);
INSERT INTO `carts` VALUES (5, 5, 1, 23, NULL);
INSERT INTO `carts` VALUES (6, 7, 1, 23, NULL);
INSERT INTO `carts` VALUES (7, 4, 1, 24, NULL);
INSERT INTO `carts` VALUES (8, 5, 1, 25, NULL);
INSERT INTO `carts` VALUES (9, 3, 1, 26, NULL);
INSERT INTO `carts` VALUES (10, 5, 2, 27, NULL);
INSERT INTO `carts` VALUES (11, 7, 5, 28, NULL);
INSERT INTO `carts` VALUES (12, 1, 2, 29, NULL);
INSERT INTO `carts` VALUES (13, 4, 2, 29, NULL);
INSERT INTO `carts` VALUES (14, 5, 1, 30, NULL);
INSERT INTO `carts` VALUES (15, 4, 1, 35, NULL);
INSERT INTO `carts` VALUES (16, 5, 2, 35, NULL);
INSERT INTO `carts` VALUES (17, 6, 1, 36, NULL);
INSERT INTO `carts` VALUES (18, 1, 3, 37, NULL);
INSERT INTO `carts` VALUES (19, 5, 2, 38, NULL);
INSERT INTO `carts` VALUES (20, 5, 2, 39, NULL);

-- ----------------------------
-- Table structure for connects
-- ----------------------------
DROP TABLE IF EXISTS `connects`;
CREATE TABLE `connects`  (
  `connect_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `connect_user_id` int(10) UNSIGNED NOT NULL,
  `connect_token` char(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `connect_token_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`connect_id`) USING BTREE,
  INDEX `connect_user_id`(`connect_user_id`) USING BTREE,
  CONSTRAINT `connect_user_id` FOREIGN KEY (`connect_user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 83 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of connects
-- ----------------------------
INSERT INTO `connects` VALUES (9, 14, '620bd2508980156ff679b7cc75253dad', '2023-03-01 17:23:56');
INSERT INTO `connects` VALUES (10, 14, '620bd2508980156ff679b7cc75253dad', '2023-03-01 17:23:56');
INSERT INTO `connects` VALUES (11, 14, '620bd2508980156ff679b7cc75253dad', '2023-03-01 17:23:56');
INSERT INTO `connects` VALUES (13, 14, 'cbf48f178ad8152d10961510d6a8cb8f', '2023-03-01 17:31:34');
INSERT INTO `connects` VALUES (22, 14, '6448b65511ca6aa8b902b4d6a229c5d0', '2023-05-23 19:19:43');
INSERT INTO `connects` VALUES (24, 14, '6f37c5888f967c4b5d49d4fa0f46cd72', '2023-06-03 13:19:18');
INSERT INTO `connects` VALUES (39, 14, '057d689ff932f1fcc11d2c084396dd63', '2023-06-17 20:47:28');
INSERT INTO `connects` VALUES (40, 14, '0bbb3cafb65554352d953f89816ad711', '2023-06-18 12:08:13');
INSERT INTO `connects` VALUES (41, 14, 'c0b4099b8b04044a8b2d240dbfcf1461', '2023-06-18 13:36:13');
INSERT INTO `connects` VALUES (42, 14, '634dbb25c1bdf5d2aa269b8a507f19a8', '2023-06-18 13:40:50');
INSERT INTO `connects` VALUES (43, 14, '7729a0c5635a5b684680faf19b21adf7', '2023-06-18 14:11:48');
INSERT INTO `connects` VALUES (46, 14, '97f573a1d3510a3f486cb9f71697a33f', '2023-06-18 15:54:47');
INSERT INTO `connects` VALUES (49, 14, '63f2ac3c97ca6b784883355b4a8fdb76', '2023-06-18 17:55:00');
INSERT INTO `connects` VALUES (51, 31, '981b5d1684c1cf63774f983670f1663b', '2023-06-18 20:05:11');
INSERT INTO `connects` VALUES (54, 14, '64a662c7bfff213f47fcb1cf6c6da606', '2023-06-19 19:06:21');
INSERT INTO `connects` VALUES (55, 32, '88b80f4b42faa1dcf2199231f2729906', '2023-06-24 19:28:48');
INSERT INTO `connects` VALUES (63, 14, 'a2bf44993a97a68cd12693f904c2dba5', '2023-06-27 18:53:55');
INSERT INTO `connects` VALUES (66, 14, '6604a14fa3ca44b4452cff18024887bd', '2023-06-27 19:04:52');
INSERT INTO `connects` VALUES (69, 14, '50b73dc156ca3379b413c3d96515546c', '2023-06-27 19:22:11');
INSERT INTO `connects` VALUES (70, 14, 'c0931a21b37c2ff74cb58c8ca4b47328', '2023-06-27 19:23:31');
INSERT INTO `connects` VALUES (71, 14, 'a701bd8009c4fcb916dfac2154202cc5', '2023-06-27 19:23:32');
INSERT INTO `connects` VALUES (72, 14, 'f5c9d713c5baa8a6fb67ffa5023617a8', '2023-06-27 19:24:17');
INSERT INTO `connects` VALUES (76, 34, 'a0aa4c65bb309f33c73fc705c10cb941', '2023-06-27 20:12:00');
INSERT INTO `connects` VALUES (77, 14, '320d25c80b11dbc5518cd3507851d28a', '2023-06-28 21:51:51');
INSERT INTO `connects` VALUES (80, 14, 'c716bb8a23ac3c60db685b8233918d10', '2023-06-28 22:47:40');
INSERT INTO `connects` VALUES (81, 14, 'c3ba2f0968aa61562b484066d65ca38f', '2023-06-28 23:24:13');
INSERT INTO `connects` VALUES (82, 14, 'bf603d158a94ab887d8a84ddf452d2dc', '2023-06-29 20:11:54');

-- ----------------------------
-- Table structure for genders
-- ----------------------------
DROP TABLE IF EXISTS `genders`;
CREATE TABLE `genders`  (
  `gender_id` tinyint(1) UNSIGNED NOT NULL AUTO_INCREMENT,
  `gender_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `gender_short_name` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`gender_id`) USING BTREE,
  UNIQUE INDEX `gender_name`(`gender_name`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of genders
-- ----------------------------
INSERT INTO `genders` VALUES (1, 'Мужской', 'М');
INSERT INTO `genders` VALUES (2, 'Женский', 'Ж');

-- ----------------------------
-- Table structure for groups
-- ----------------------------
DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups`  (
  `group_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `group_translit` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `group_level` int(3) UNSIGNED NULL DEFAULT NULL,
  `group_parent_id` int(10) UNSIGNED NULL DEFAULT NULL,
  PRIMARY KEY (`group_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of groups
-- ----------------------------
INSERT INTO `groups` VALUES (1, 'VoIP', 'voip', 1, 0);
INSERT INTO `groups` VALUES (2, 'Активное сетевое', 'aktivnoe_setevoe', 1, 0);
INSERT INTO `groups` VALUES (3, 'Пассивное сетевое', 'passivnoe_setevoe', 1, 0);
INSERT INTO `groups` VALUES (4, 'Серверы', 'servery', 1, 0);
INSERT INTO `groups` VALUES (5, 'Межсетевые экраны', 'mezhsetevye_ekrany', 2, 2);
INSERT INTO `groups` VALUES (6, 'СХД', 'sistemy_hraneniya_dannyh', 2, 0);
INSERT INTO `groups` VALUES (7, 'Прочее', 'prochee', 1, 0);
INSERT INTO `groups` VALUES (8, 'Каталог', 'katalog', 0, 0);
INSERT INTO `groups` VALUES (9, 'Телефоны', 'telefony', 2, 1);
INSERT INTO `groups` VALUES (10, 'АТС', 'ats', 2, 1);
INSERT INTO `groups` VALUES (11, 'Коммутаторы', 'kommutatory', 2, 2);
INSERT INTO `groups` VALUES (12, 'Телекоммуникационные стойки ', 'telekommunikacionnye_stojki', 2, 3);
INSERT INTO `groups` VALUES (13, 'Телекоммуникационные шкафы', 'telekommunikacionnye_shkafy', 2, 3);
INSERT INTO `groups` VALUES (14, 'Серверные платформы', 'servernye_platformy', 2, 4);
INSERT INTO `groups` VALUES (15, 'СХД для дома', 'skhd_dlya_doma', 2, 6);

-- ----------------------------
-- Table structure for manufacturers
-- ----------------------------
DROP TABLE IF EXISTS `manufacturers`;
CREATE TABLE `manufacturers`  (
  `manufacturer_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `manufacturer_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `manufacturer_translit` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `manufacturer_description` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `manufacturer_is_deleted` tinyint(1) UNSIGNED NOT NULL,
  PRIMARY KEY (`manufacturer_id`) USING BTREE,
  UNIQUE INDEX `manufacturer_name`(`manufacturer_name`) USING BTREE,
  UNIQUE INDEX `manufacturer_translit`(`manufacturer_translit`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 45 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of manufacturers
-- ----------------------------
INSERT INTO `manufacturers` VALUES (1, 'Yealink', 'yealink', 'Основанная в 2001 году, компания Yealink Network Technology является ведущим мировым производителем абонентского оборудования для IP-телефонии и видео-конференц-связи. Фокус компании Yealink полностью сосредоточен на IP-коммуникациях, поэтому продукты компании отличаются высоким качеством, надежностью, легкостью развертывания и доступной ценой. Сегодня клиенты во всех отраслях бизнеса в более чем 140 странах выбирают оборудование Yealink для повышения надежности, качества и эргономичности коммуникационных сетей.', 0);
INSERT INTO `manufacturers` VALUES (2, 'Yeastar', 'yeastar', 'Компания Yeastar Information Technology c 2006 года разрабатывает и производит гибридные IP-АТС и VoIP-шлюзы, постоянно работая над улучшением своих продуктов, чтобы соответствовать технологиям нового поколения в области связи. Yeastar создает экономически эффективные решения для офисов малого и среднего бизнеса, которые сочетают в себе все необходимые стандарты и протоколы связи. Такой набор позволяет добиться непревзойденной универсальности и гибкости телекоммуникационного решения. Компания входит в число признанных мировых производителей АТС и зарекомендовала себя как надежный и технологичный партнер.', 0);
INSERT INTO `manufacturers` VALUES (3, 'Zyxel', 'zyxel', 'Крупная международная компания со штаб-квартирой на Тайване, известный производитель сетевого оборудования для среднего и малого бизнеса, промышленных предприятий и дома.', 0);
INSERT INTO `manufacturers` VALUES (4, 'ЦМО', 'cmo', 'Один из лидеров по производству телекоммуникационных и электротехнических шкафов в России и странах СНГ. Продукция ЦМО помогает оснащать небольшие офисы и строить крупные сети, размещать активное оборудование на улице и в производственных цехах.', 0);
INSERT INTO `manufacturers` VALUES (5, 'Supermicro', 'supermicro', 'Американская компания, крупный производитель материнских плат, корпусов, источников питания, систем охлаждения, контроллеров SAS, Ethernet и InfiniBand. Компания специализируется на выпуске x86-серверных платформ и различных комплектующих для серверов, рабочих станций и систем хранения данных.', 0);
INSERT INTO `manufacturers` VALUES (6, 'Qnap', 'qnap', 'Компания-производитель сетевых систем хранения данных и видеорегистраторов. Программное обеспечение собственной разработки базируется на операционных системах Linux и FreeBSD. Полное наименование — QNAP Systems Incorporated, название расшифровывается как «поставщик качественных сетевых устройств».', 0);
INSERT INTO `manufacturers` VALUES (42, '2706', NULL, '2706', 1);
INSERT INTO `manufacturers` VALUES (43, 'Вася!', NULL, 'Вася!', 0);
INSERT INTO `manufacturers` VALUES (44, 'Не падай mysql', NULL, ' Не падай mysql, пожалуйста', 0);

-- ----------------------------
-- Table structure for marks
-- ----------------------------
DROP TABLE IF EXISTS `marks`;
CREATE TABLE `marks`  (
  `mark_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `mark_value` tinyint(1) UNSIGNED NOT NULL,
  `mark_user_id` int(10) UNSIGNED NOT NULL,
  `mark_product_id` int(10) UNSIGNED NOT NULL,
  `mark_comment` tinytext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`mark_id`) USING BTREE,
  INDEX `mark_product_id`(`mark_product_id`) USING BTREE,
  INDEX `mark_user_id`(`mark_user_id`) USING BTREE,
  CONSTRAINT `mark_product_id` FOREIGN KEY (`mark_product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `mark_user_id` FOREIGN KEY (`mark_user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of marks
-- ----------------------------
INSERT INTO `marks` VALUES (3, 5, 1, 1, 'Вау!');
INSERT INTO `marks` VALUES (4, 2, 3, 12, 'Вау!');
INSERT INTO `marks` VALUES (5, 3, 2, 3, 'Вай!');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders`  (
  `order_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_user_id` int(10) UNSIGNED NULL DEFAULT NULL,
  `order_status_id` tinyint(2) UNSIGNED NOT NULL,
  `order_create_time` datetime(0) NULL DEFAULT current_timestamp,
  PRIMARY KEY (`order_id`) USING BTREE,
  INDEX `order_status_id`(`order_status_id`) USING BTREE,
  INDEX `order_user_id`(`order_user_id`) USING BTREE,
  CONSTRAINT `order_status_id` FOREIGN KEY (`order_status_id`) REFERENCES `statuses` (`status_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `order_user_id` FOREIGN KEY (`order_user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 40 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES (1, 1, 1, '2023-06-17 20:53:13');
INSERT INTO `orders` VALUES (2, 1, 2, '2023-06-17 20:53:13');
INSERT INTO `orders` VALUES (3, 3, 2, '2023-06-17 20:53:13');
INSERT INTO `orders` VALUES (23, 14, 1, '2023-06-18 15:14:19');
INSERT INTO `orders` VALUES (24, 14, 1, '2023-06-18 15:24:49');
INSERT INTO `orders` VALUES (25, 14, 1, '2023-06-18 15:25:25');
INSERT INTO `orders` VALUES (26, 14, 1, '2023-06-18 16:44:09');
INSERT INTO `orders` VALUES (27, 14, 1, '2023-06-18 17:22:48');
INSERT INTO `orders` VALUES (28, 14, 1, '2023-06-18 17:27:58');
INSERT INTO `orders` VALUES (29, 14, 1, '2023-06-18 19:18:11');
INSERT INTO `orders` VALUES (30, 14, 1, '2023-06-18 19:34:51');
INSERT INTO `orders` VALUES (31, 14, 1, '2023-06-19 18:05:55');
INSERT INTO `orders` VALUES (32, 14, 1, '2023-06-19 18:36:26');
INSERT INTO `orders` VALUES (33, 14, 1, '2023-06-19 18:37:36');
INSERT INTO `orders` VALUES (34, 14, 1, '2023-06-19 18:37:43');
INSERT INTO `orders` VALUES (35, 14, 1, '2023-06-19 18:39:37');
INSERT INTO `orders` VALUES (36, 14, 1, '2023-06-19 18:40:34');
INSERT INTO `orders` VALUES (37, 34, 1, '2023-06-28 22:16:44');
INSERT INTO `orders` VALUES (38, 14, 1, '2023-06-28 22:21:47');
INSERT INTO `orders` VALUES (39, 14, 1, '2023-06-28 22:54:15');

-- ----------------------------
-- Table structure for products
-- ----------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products`  (
  `product_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_art` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_description` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `product_price` int(10) UNSIGNED NOT NULL,
  `product_quantity` int(11) NULL DEFAULT NULL,
  `product_manufacturer_id` int(10) UNSIGNED NULL DEFAULT NULL,
  `product_group_id` int(10) UNSIGNED NULL DEFAULT NULL,
  `product_is_deleted` tinyint(1) UNSIGNED NOT NULL,
  PRIMARY KEY (`product_id`) USING BTREE,
  INDEX `product_manufacturer_id`(`product_manufacturer_id`) USING BTREE,
  INDEX `product_group_id`(`product_group_id`) USING BTREE,
  FULLTEXT INDEX `product_art`(`product_art`),
  FULLTEXT INDEX `product_name`(`product_name`),
  CONSTRAINT `product_group_id` FOREIGN KEY (`product_group_id`) REFERENCES `groups` (`group_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `product_manufacturer_id` FOREIGN KEY (`product_manufacturer_id`) REFERENCES `manufacturers` (`manufacturer_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 45 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of products
-- ----------------------------
INSERT INTO `products` VALUES (1, 'SIP-T30', 'Телефон IP', 'Yealink SIP-T30 — классический IP-телефон начального уровня, предназначенный для рядовых офисных сотрудников и малого бизнеса. SIP-T30 обеспечивает простой и удобный набор номера, оснащен большим графическим ЖК-дисплеем с разрешением 132x64 пикселей, позволяющим вывести достаточно большой объем визуальной информации на экран. Два сетевых порта 10/100 Мбит делают SIP-T30 идеальным выбором для расширенного использования в сети. SIP-T30 поддерживает 1 SIP-аккаунт и 5-стороннюю аудиоконференцию. SIP-T30 поддерживает использование Yealink EHS35 для подключения беспроводной гарнитуры Yealink, укомплектован подставкой с регулируемым углом наклона. SIP-T30 отличается отсутствием поддержки PoE от модели Yealink T30P.', 3303, 999, 1, 9, 0);
INSERT INTO `products` VALUES (3, 'SIP-T30P', 'Телефон IP', 'Yealink SIP-T30P — классический IP-телефон начального уровня, предназначенный для рядовых офисных сотрудников и малого бизнеса. SIP-T30P обеспечивает простой и удобный набор номера, оснащен большим графическим ЖК-дисплеем с разрешением 132x64 пикселей, позволяющим вывести достаточно большой объем визуальной информации на экран. Два сетевых порта 10/100 Мбит делают SIP-T30P идеальным выбором для расширенного использования в сети. SIP-T30P поддерживает 1 SIP-аккаунт и 5-стороннюю аудиоконференцию. SIP-T30P поддерживает использование Yealink EHS35 для подключения беспроводной гарнитуры Yealink, укомплектован подставкой с регулируемым углом наклона. SIP-T30P поддерживает питание по PoE, чем и отличается от модели Yealink T30.', 3725, 999, 1, 9, 0);
INSERT INTO `products` VALUES (4, 'S20', 'АТС', 'Yeastar S20 — это младшая модель в линейке IP-АТС S-серии. S20 предназначена для малого бизнеса и удаленных подразделений (офисов, филиалов). Поддерживает до 20 абонентов и до 10 одновременных вызовов. Помимо работы в VoIP сетях, S20 позволяет подключать аналоговые линии/телефоны, линии BRI и GSM-линию. Имеет функцию автоматической записи разговора.', 34500, 2, 2, 10, 0);
INSERT INTO `products` VALUES (5, 'S50', 'АТС', 'Yeastar S50 — это IP-АТС из новой линейки S-серии на 50 абонентов и 25 одновременных вызовов. S50 может работать в VoIP сетях, имеет возможность подключать аналоговые линии/телефоны, линии BRI и GSM-линию. Имеет поддержку технологии Gigabit Ethernet.', 56904, 2, 2, 10, 0);
INSERT INTO `products` VALUES (6, 'GS1100-24E', 'Коммутатор', 'Неуправляемый. 24 порта RJ45 10/100/1000 Мбит/сек. Пропускная способность 48 Гбит/с. Скорость пересылки пакетов 35,7 Мп/с. Таблица MAC адресов 8 K. Автоопределение MDI/MDI-X. Поддержка 802.1p CoS. Транзит VLAN. Безвентиляторная система охлаждения.', 15000, 5, 3, 11, 0);
INSERT INTO `products` VALUES (7, 'GS1920-8HPv2', 'Коммутатор', 'NebulaFlex это уникальная технология Zyxel, которая позволяет устройствам, которые обычно предназначены для автономной работы, незаметно интегрироваться в платформу Nebula. Это дает вам как клиенту высокую гибкость и широкий выбор способов настройки ваших устройств.', 29539, 5, 3, 11, 0);
INSERT INTO `products` VALUES (8, 'ШРН-Э-9.650.1', 'Шкаф', 'ЦМО ШРН-Э-9.650.1 - 19\", настенный, разборный, телекоммуникационный шкаф высотой 9U и глубиной 650 мм. Дверь изготовлена из металла.', 8560, 5, 4, 13, 0);
INSERT INTO `products` VALUES (9, 'СТК-42.2-9005', 'Стойка', 'ЦМО СТК-42.2-9005 - 19\" телекоммуникационная универсальная двухрамная стойка высотой 42U. Конструкция предусматривает регулировку полезной глубины. Цвет черный.', 17629, 5, 4, 12, 0);
INSERT INTO `products` VALUES (10, '6029P-WTRT', 'Сервер', 'Сервер Supermicro SuperServer 6029P-WTRT без процессора/без ОЗУ/без накопителей/количество отсеков 3.5\" hot swap: 12/LAN 10 Гбит/c', 307324, 1, 5, 14, 0);
INSERT INTO `products` VALUES (11, '1029P-WTRT', 'Сервер', 'Сервер Supermicro SuperServer 1029P-WTRT без процессора/без ОЗУ/без накопителей/количество отсеков 2.5\" hot swap: 10/2 x 750 Вт/LAN 10 Гбит/c', 719000, 1, 5, 14, 0);
INSERT INTO `products` VALUES (12, 'D2 Pro', 'Сетевое хранилище', 'Название Сетевой накопитель (NAS) QNAP D2 Pro. Категория Сетевые накопители. Количество мест под HDD 2. Интерфейс Ethernet есть. Тип контроллера Ethernet 2x1000 Мбит-с. HDMI-выход есть. Внутренний интерфейс SATA. Внутренний стандарт SATA 6Gb-s. Общее количество разъемов USB Type A 3. Количество разъемов USB 3.0 Type A 3. Адаптер питания есть. Поддержка RAID 0 есть. Поддержка RAID 1 есть. Кнопка резервного копирования есть. Принт-сервер есть. FTP-сервер есть. DLNA-сервер есть. Поддержка сетевого протокола iSCSI есть. Поддержка ip-видеонаблюдения есть. Максимальное количество ip-камер 32. Процессор Intel Celeron. Частота процессора 1600 МГц. Количество ядер процессора 2. Тип оперативной памяти DDR3. Размер оперативной памяти 1 ГБ. Возможность увеличения объема оперативной памяти есть. Внутренняя поддержка файловой системы EXT4 есть. Внешняя поддержка файловой системы EXT3 есть. Внешняя поддержка файловой системы EXT4 есть. Внешняя поддержка файловой системы NTFS есть. Внешняя поддержка файловой системы FAT32 есть. Внешняя поддержка файловой системы HFS+ есть. Потребляемая мощность 17 Вт. Потребляемая мощность в спящем режиме 8 Вт. Мин. рабочая температура 1 градусовC. Макс. рабочая температура 40 градусовC. Ширина 102 мм. Высота 169 мм. Длина 219 мм. Вес 1300 г. Дополнительная информация 1 mini-jack (3,5 мм); слот для SD карты;.', 37040, 2, 6, 15, 0);
INSERT INTO `products` VALUES (13, 'HS-264-8G', 'Сетевое хранилище', 'Разработанный как мультимедийный центр для умного дома, HS-264 включает функциональный набор для хранения, и воспроизведения разнообразного контента на основе приложений и утилит, таких как QuMagie, Video Station, Music Station и Plex Media Server.', 95828, 2, 6, 15, 0);
INSERT INTO `products` VALUES (14, 'SIP-T41', 'Телефон IP', 'Yealink SIP-T41', 4303, 2, 1, 9, 0);
INSERT INTO `products` VALUES (15, 'SIP-T42', 'Телефон IP', 'Yealink SIP-T42', 6570, 3, 1, 9, 0);
INSERT INTO `products` VALUES (16, 'SIP-T44', 'Телефон IP', 'Yealink SIP-T44', 4303, 2, 1, 9, 0);
INSERT INTO `products` VALUES (17, 'SIP-T45', 'Телефон IP', 'Yealink SIP-T45', 6570, 3, 1, 9, 0);
INSERT INTO `products` VALUES (18, 'SIP-T51', 'Телефон IP', 'SIP-T51', 14303, 2, 1, 9, 0);
INSERT INTO `products` VALUES (19, 'SIP-T52', 'Телефон IP', 'SIP-T52', 16570, 3, 1, 9, 0);
INSERT INTO `products` VALUES (20, 'SIP-T54', 'Телефон IP', 'SIP-T54', 14303, 2, 1, 9, 0);
INSERT INTO `products` VALUES (21, 'SIP-T55', 'Телефон IP', 'SIP-T55', 16570, 3, 1, 9, 0);

-- ----------------------------
-- Table structure for statuses
-- ----------------------------
DROP TABLE IF EXISTS `statuses`;
CREATE TABLE `statuses`  (
  `status_id` tinyint(2) UNSIGNED NOT NULL AUTO_INCREMENT,
  `status_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `status_is_deleted` tinyint(1) UNSIGNED NULL DEFAULT NULL,
  PRIMARY KEY (`status_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of statuses
-- ----------------------------
INSERT INTO `statuses` VALUES (1, 'Создан', NULL);
INSERT INTO `statuses` VALUES (2, 'В обработке', NULL);
INSERT INTO `statuses` VALUES (3, 'Оплачен', NULL);
INSERT INTO `statuses` VALUES (4, 'Выдан', NULL);
INSERT INTO `statuses` VALUES (5, 'Отменен', NULL);
INSERT INTO `statuses` VALUES (6, '1234567891', NULL);
INSERT INTO `statuses` VALUES (7, 'Новый статус 56', 1);
INSERT INTO `statuses` VALUES (8, 'Статус1', NULL);
INSERT INTO `statuses` VALUES (9, 'проверка', NULL);

-- ----------------------------
-- Table structure for stocks
-- ----------------------------
DROP TABLE IF EXISTS `stocks`;
CREATE TABLE `stocks`  (
  `stocks_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `stock_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stock_description` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stock_products_price` int(10) NULL DEFAULT NULL,
  `stock_product_id` int(10) UNSIGNED NULL DEFAULT NULL,
  PRIMARY KEY (`stocks_id`) USING BTREE,
  INDEX `stock_product_id`(`stock_product_id`) USING BTREE,
  CONSTRAINT `stock_product_id` FOREIGN KEY (`stock_product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of stocks
-- ----------------------------
INSERT INTO `stocks` VALUES (1, 'Телефон Yealink sip-t30', 'При покупке телефонов Yealink sip-t30 получите промо цену', 3000, 1);
INSERT INTO `stocks` VALUES (2, 'АТС S20', 'В честь открытия магазина дарим скидку на АТС Yeastar S20', 30000, 4);
INSERT INTO `stocks` VALUES (3, '1029P-WTRT', 'Большая скидка для большого железа 1029P-WTRT. Успей!', 700000, 11);

-- ----------------------------
-- Table structure for stocks_products_connection
-- ----------------------------
DROP TABLE IF EXISTS `stocks_products_connection`;
CREATE TABLE `stocks_products_connection`  (
  `stocks_products_connection_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `stocks_con_product_id` int(10) UNSIGNED NULL DEFAULT NULL,
  `stocks_con_stocks_id` int(10) UNSIGNED NULL DEFAULT NULL,
  PRIMARY KEY (`stocks_products_connection_id`) USING BTREE,
  INDEX `stocks_con_product_id`(`stocks_con_product_id`) USING BTREE,
  INDEX `stocks_con_stocks_id`(`stocks_con_stocks_id`) USING BTREE,
  CONSTRAINT `stocks_con_product_id` FOREIGN KEY (`stocks_con_product_id`) REFERENCES `products` (`product_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `stocks_con_stocks_id` FOREIGN KEY (`stocks_con_stocks_id`) REFERENCES `stocks` (`stocks_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of stocks_products_connection
-- ----------------------------
INSERT INTO `stocks_products_connection` VALUES (1, 1, 1);
INSERT INTO `stocks_products_connection` VALUES (2, 4, 2);
INSERT INTO `stocks_products_connection` VALUES (3, 11, 3);

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_fio` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `user_email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `user_password` char(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `user_dob` date NOT NULL,
  `user_gender_id` tinyint(1) UNSIGNED NULL DEFAULT NULL,
  `user_is_admin` tinyint(1) UNSIGNED NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`) USING BTREE,
  UNIQUE INDEX `user_email`(`user_email`) USING BTREE COMMENT 'авторизация',
  INDEX `user_gender_id`(`user_gender_id`) USING BTREE,
  CONSTRAINT `user_gender_id` FOREIGN KEY (`user_gender_id`) REFERENCES `genders` (`gender_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 35 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'Иванов Иван Иванович', 'ivan@mail.com', 'qQ11', '2000-01-01', 1, 0);
INSERT INTO `users` VALUES (2, 'Сидорова Анна Ивановна', 'sidr@mail.com', 'qQ11', '2000-01-03', 2, 0);
INSERT INTO `users` VALUES (3, 'Петров Петр Иванович', 'petr@mail.com', 'qQ11', '2000-01-03', 1, 0);
INSERT INTO `users` VALUES (8, NULL, 'ivan_m@mail.com', 'qQ11', '0000-00-00', NULL, 0);
INSERT INTO `users` VALUES (14, NULL, 'petr123@mail.com', '8059db03c74905062bad1787306580bc', '0000-00-00', NULL, 1);
INSERT INTO `users` VALUES (24, NULL, 'petr1234@mail.com', '8059db03c74905062bad1787306580bc', '0000-00-00', NULL, 0);
INSERT INTO `users` VALUES (25, NULL, 'petr12345@mail.com', '8059db03c74905062bad1787306580bc', '0000-00-00', NULL, 0);
INSERT INTO `users` VALUES (26, NULL, 'petr1234657@mail.com', '8059db03c74905062bad1787306580bc', '0000-00-00', NULL, 0);
INSERT INTO `users` VALUES (27, NULL, 'petr12399@mail.com', '8059db03c74905062bad1787306580bc', '0000-00-00', NULL, 0);
INSERT INTO `users` VALUES (28, NULL, 'petr123000000@mail.com', '8059db03c74905062bad1787306580bc', '0000-00-00', NULL, 0);
INSERT INTO `users` VALUES (29, NULL, 'petr1223543@mail.com', '8059db03c74905062bad1787306580bc', '0000-00-00', NULL, 0);
INSERT INTO `users` VALUES (30, NULL, 'petr123123123@mail.com', '8059db03c74905062bad1787306580bc', '0000-00-00', NULL, 0);
INSERT INTO `users` VALUES (31, NULL, 'petr123r2rwrewr@mail.com', '8059db03c74905062bad1787306580bc', '0000-00-00', NULL, 0);
INSERT INTO `users` VALUES (32, NULL, 'petr123234876@mail.com', '8059db03c74905062bad1787306580bc', '0000-00-00', NULL, 0);
INSERT INTO `users` VALUES (33, NULL, 'petr123----@mail.com', '8059db03c74905062bad1787306580bc', '0000-00-00', NULL, 0);
INSERT INTO `users` VALUES (34, NULL, 'petr123111@mail.com', '8059db03c74905062bad1787306580bc', '0000-00-00', NULL, 0);

SET FOREIGN_KEY_CHECKS = 1;
